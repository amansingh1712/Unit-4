import React from "react";

const Mens = () => {
  return <h1>Mens</h1>;
};

export default Mens;
