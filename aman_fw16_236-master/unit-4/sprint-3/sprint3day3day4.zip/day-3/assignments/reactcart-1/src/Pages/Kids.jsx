import React from "react";

const Kids = () => {
  return <h1>Kids</h1>;
};

export default Kids;
