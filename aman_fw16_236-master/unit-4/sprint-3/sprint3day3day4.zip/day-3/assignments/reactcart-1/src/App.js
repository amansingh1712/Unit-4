import "./styles.css";
import MainWindow from "./Components/MainWindow";

export default function App() {
  return (
    <div className="App">
      <MainWindow />
    </div>
  );
}