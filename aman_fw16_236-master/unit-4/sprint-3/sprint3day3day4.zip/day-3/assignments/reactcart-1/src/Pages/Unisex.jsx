import React from "react";

const Unisex = () => {
  return <h1>Unisex</h1>;
};

export default Unisex;
