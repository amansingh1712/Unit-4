import React from "react";

const JobOpportunities = () => {
  return <h1>Job Opportunities</h1>;
};

export default JobOpportunities;
