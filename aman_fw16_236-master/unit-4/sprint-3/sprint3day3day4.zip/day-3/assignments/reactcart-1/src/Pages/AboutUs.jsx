import React from "react";

const AboutUs = () => {
  return <h1>About us</h1>;
};

export default AboutUs;
