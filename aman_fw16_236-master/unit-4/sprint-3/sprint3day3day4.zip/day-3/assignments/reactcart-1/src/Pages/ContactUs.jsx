import React from "react";

const ContactUs = () => {
  return <h1>Contact us</h1>;
};

export default ContactUs;
