import React from "react";

const Women = () => {
  return <h1>Women</h1>;
};

export default Women;
